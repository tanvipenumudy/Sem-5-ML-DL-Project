# Python-Web-App
A Web app which asks for email and height and then computes the average height among all the entered heights till now and then sends an email to the entered email. Made using HTML and CSS for frontend and Python and Flask for the backend and PostgreSQL(SQLAlchemy) as the database.
